g++ em.cpp -o em -O3
./em input.txt output.txt