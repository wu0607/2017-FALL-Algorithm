$ g++ bezier.cpp -o bezier -O3
$ ./bezier test.in test.out
